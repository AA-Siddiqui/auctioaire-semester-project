package com.example.auctioaire

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
